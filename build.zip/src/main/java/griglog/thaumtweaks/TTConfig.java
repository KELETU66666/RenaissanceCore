package griglog.thaumtweaks;

import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ThaumTweaks.MODID)
@Config(modid = ThaumTweaks.MODID, category = "")
public class TTConfig {
    @Config.Name("General")
    public static General general = new General();

    @Config.Name("Blocks")
    public static Blocks blocks = new Blocks();

    public static class General {
        @Config.Name("Tweak materials (tools' and armors' stats)")
        public boolean materialOverride = true;
        @Config.Name("Golems can start infusions")
        public boolean autoInfusion = true;
        @Config.Name("Tweaked pech trades")
        public boolean pechs = true;
        @Config.Name("Research table can fetch items from adjacent containers")
        public boolean researchTable = true;
    }

    public static class Blocks {
        @Config.Name("Pedestals output redstone signal")
        public boolean pedestal = true;
        @Config.Name("Smelteries can be accessed by hoppers")
        public boolean smeltery = true;
    }

    @SubscribeEvent
    public static void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equals(ThaumTweaks.MODID))
            ConfigManager.sync(event.getModID(), Config.Type.INSTANCE);
    }
}
