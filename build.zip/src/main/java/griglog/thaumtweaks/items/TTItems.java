package griglog.thaumtweaks.items;

import griglog.thaumtweaks.ThaumTweaks;
import griglog.thaumtweaks.blocks.TTBlocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.GameRegistry;


public class TTItems {
    public static final Item filler = new ItemFiller();
    public static final Item rift_feed = new Item().setRegistryName("rift_feed").setTranslationKey("rift_feed");
    public static final Item arcaneCrafterItem = new ItemBlock(TTBlocks.arcaneCrafter)
            .setRegistryName(TTBlocks.arcaneCrafter.getRegistryName())
            .setTranslationKey(TTBlocks.arcaneCrafter.getTranslationKey());
}
