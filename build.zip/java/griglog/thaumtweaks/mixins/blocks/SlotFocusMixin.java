package griglog.thaumtweaks.mixins.blocks;

import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import thaumcraft.common.container.slot.SlotFocus;
import thaumcraft.common.items.casters.ItemFocus;

@Mixin(SlotFocus.class)
public class SlotFocusMixin {

    /**
     * @author keletu
     * @reason you know why
     */
    @Overwrite
    public boolean isItemValid(ItemStack stack){
        return stack.getTagCompound() == null && stack != null && !stack.isEmpty() && stack.getItem() != null && stack.getItem() instanceof ItemFocus;
    }

}
