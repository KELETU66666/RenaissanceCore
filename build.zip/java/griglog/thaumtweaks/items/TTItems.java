package griglog.thaumtweaks.items;

import net.minecraft.item.Item;

public class TTItems {
    public static final Item rift_feed = new Item().setRegistryName("rift_feed").setTranslationKey("rift_feed");
}
