package griglog.thaumtweaks.entity;

public enum PechType {
    MINER, MAGE, ARCHER, COMMON
}
