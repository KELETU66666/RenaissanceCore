package griglog.thaumtweaks.blocks;

import griglog.thaumtweaks.blocks.crafter.BlockArcaneCrafter;
import net.minecraft.block.Block;

public class TTBlocks {
    public static Block arcaneCrafter = new BlockArcaneCrafter();
}
